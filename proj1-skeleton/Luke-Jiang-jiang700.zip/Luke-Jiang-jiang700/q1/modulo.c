#include <stdio.h>

int main()
{
    printf("%i", (-5) % 2);

    return 0;
}
