print((-5) % 2)
